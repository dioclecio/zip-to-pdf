---
title: "Relatório do Segundo Arquivo"
---
# Esse é o segundo arquivo para PDF



Vamos fazer novamente mais um teste com imagens.

Somente um **teste de espaço                    **. 

![Essa é a legenda automática 01](./assets/mikhail-vasilyev-IFxjDdqK_0U-unsplash-1737912254934-3.jpg){#fig:figura01}

![Essa é a legenda automática 02](./assets/kate-stone-matheson-uy5t-CJuIK4-unsplash.jpg){#fig:figura02}

![Essa é a legenda automática 03](./assets/kate-stone-matheson-Gzs04ADxn6Q-unsplash-1737912293838-8.jpg){#fig:figura03}

![Essa é a legenda automática 04](./assets/mikhail-vasilyev-IFxjDdqK_0U-unsplash-1737912254934-3.jpg){#fig:figura04}

Aqui vamos entrar com o texto, apontando para a [@fig:figura01]. Agora vamos para a [@fig:figura02], depois a [@fig:figura03] e por fim a [@fig:figura04].
