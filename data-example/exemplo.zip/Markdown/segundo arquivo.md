# Esse é o segundo arquivo para PDF



Vamos fazer novamente mais um teste com imagens.

![](./assets/003.jpg)



Mais uma foto para testar.



![](./assets/004.jpg)